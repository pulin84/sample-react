import React,{ Component } from 'react';
import DatePicker from 'react-datepicker';

import "react-datepicker/dist/react-datepicker.css";

class SaveModal extends Component {

    constructor(props){
        super(props);
    }

    validateDate() {
        if (!this.props.businessStartDate) return true;
    }

    render() {
        return <div className="modal fade bd-example-modal-lg" id="mappingModal"
        tabIndex="-1" role="dialog" aria-labelledby="mappingModalTitle"
        aria-hidden="true">
        <div className="modal-dialog modal-lg" role="document">
            <div className="modal-content">
                <div className="modal-header">
                    <h5 className="modal-title">{this.props.mappingModalTitle}</h5>
                    <button type="button" className="close" data-dismiss="modal"
                        aria-label="Close" onClick={this.props.resetBusinessStartDate}>
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div className="modal-body">
                    <div className="form-group row mt-2">
                        <div className="col-md-3">
                            <label htmlFor="businessStartDate">Business Start Date</label>
                        </div>
                        <div className="col-md-3">
                            <DatePicker className="form-control"
                                 style={{background:'white'}} selected={this.props.businessStartDate} onChange={this.props.setSelectedDate} placeholderText="mm/dd/yyyy" />
                        </div>
                    </div>
                </div>
                <div className="modal-footer">
                    <button type="button" className="btn btn-secondary" data-dismiss="modal" onClick={this.props.resetBusinessStartDate}>Close</button>
                    <button id="saveChanges" type="button" className="btn btn-primary" onClick={this.props.save} disabled={this.validateDate()}>Save changes</button>
                </div>
            </div>
        </div>
    </div>
    }
}

class DeleteModal extends Component{

    render() {
        return <div className="modal fade bd-example-modal-lg" id="deleteConfirmModal"
        tabIndex="-1" role="dialog" aria-labelledby="deleteConfirmModalTitle"
        aria-hidden="true">
        <div className="modal-dialog modal-lg" role="document">
            <div className="modal-content">
                <div className="modal-header">
                    <h5 className="modal-title" id="deleteConfirmModalTitle">Confirmation needed!</h5>
                    <button type="button" className="close" data-dismiss="modal"
                        aria-label="Close" onClick={this.resetIndexNumToDelete}>
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div className="modal-body">
                    <h5>Are you sure want to delete?</h5>
                </div>
                <div className="modal-footer">
                    <button type="button" className="btn btn-secondary" data-dismiss="modal" onClick={this.resetIndexNumToDelete}>No</button>
                    <button  id="deleteMapping" type="button" className="btn btn-primary" data-dismiss="modal" onClick={this.props.deleteRow}>Yes</button>
                </div>
            </div>
        </div>
    </div>
    }
}

export default SaveModal;

export {
    DeleteModal,
    SaveModal
}


