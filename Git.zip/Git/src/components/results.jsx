import React,{ Component } from 'react';
import { faPlusSquare } from '@fortawesome/free-solid-svg-icons'
import { faMinusSquare } from '@fortawesome/free-solid-svg-icons'

import { library } from '@fortawesome/fontawesome-svg-core';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { DeleteModal} from './modal';


class Results extends Component {

    constructor(props) {
        super(props);
        library.add(faPlusSquare, faMinusSquare);
    }

    state = {
        selectedInputToOutput : '',
        outputInputFontAwesomeIcon : "plus-square",
        validationRuleFontAwesomeIcon : "plus-square"
    }

    indexNumToDelete = -1;

    renderInputColumn(input, index) {
        if (input !== 'null'){
            return input;
        } else {
          return <select className="form-control" id="inputPathSelectId" value={this.state.selectedInputToOutput} onChange={(event) => this.props.setSelectedInputToOutput(event, index)}>
                        <option value="NA">Not Applicable</option>
                        {this.props.availableInputPaths.map(availableInputPath => <option key={availableInputPath}>{availableInputPath}</option>)}
				</select>
        }
    }

    setFontAwesomeIcon = (property, className) => {
        this.setState({[property] : className === "plus-square" ? "minus-square" : "plus-square"})
    }

    renderInputOutputMappingClassName(output, input) {
        if (input === "null") {
            let rule = null;
           
            this.props.validationRules.forEach((item) => {
                if(item.split("=")[0] === output){
                    rule = item.split("=")[1];
                    return;
                }
            });

            if (rule === 'O'){
                return 'table-warning';
            } else if (rule === 'R'){
                return 'table-danger';
            }
        }
    }

    setIndexNumToDelete = (index) => {
        this.indexNumToDelete = index;
    }

    resetIndexNumToDelete = () => {
        this.indexNumToDelete = -1;
    }

    deleteRow = () => {
        this.props.deleteRow(this.indexNumToDelete);
    }

    render(){
        return this.props.inputOutputMappings.length === 0 && this.props.validationRules.length === 0 ? '' : 
        <span>    
        <div className="form-group row mt-4 ml-2">
        <i className='mt-1' data-target="#inputOutputTable" aria-expanded="false" aria-controls="collapse" data-toggle="collapse" onClick={() => this.setFontAwesomeIcon("outputInputFontAwesomeIcon", this.state.outputInputFontAwesomeIcon)}>
        <FontAwesomeIcon icon={this.state.outputInputFontAwesomeIcon}></FontAwesomeIcon>
        </i>&nbsp;&nbsp;
        <strong>Input Output Mapping</strong>
        <table className="table table-sm collapse mt-2" id="inputOutputTable">
            <thead>
                <tr>
                    <th scope="col">Output</th>
                    <th scope="col">=</th>
                    <th scope="col">Input</th>
                    <td></td>
                </tr>
            </thead>
            <tbody>
                {this.props.inputOutputMappings.map((item, index) => 
                <tr key={item} className={this.renderInputOutputMappingClassName(item.split("=")[0], item.split("=")[1])}>
                    <td>{item.split("=")[0]}</td>
                    <td>=</td>
                    <td>{this.renderInputColumn(item.split("=")[1], index)}</td>
                     <td>
                         <button className="btn btn-danger" type="button" data-toggle="modal" onClick={this.setIndexNumToDelete} data-target="#deleteConfirmModal">
                                                   Delete
                          </button>
                     </td>
                    
                </tr>
                )}
            </tbody>
        </table>
    </div>
    <div className="form-group row mt-4 ml-2" >
    <i className="mt-1" data-target="#validationRuleTable" aria-expanded="false" aria-controls="collapse" data-toggle="collapse" onClick={() => this.setFontAwesomeIcon("validationRuleFontAwesomeIcon", this.state.validationRuleFontAwesomeIcon)}>
       <FontAwesomeIcon icon={this.state.validationRuleFontAwesomeIcon}></FontAwesomeIcon>
    </i>&nbsp;&nbsp;
    <strong>Validation Rules</strong>
    <br></br>
        <table className="table table-sm collapse mt-2" id="validationRuleTable">
            <thead>
                <tr>
                    <th scope="col">Path</th>
                    <th scope="col">=</th>
                    <th scope="col">Rule</th>
                </tr>
            </thead>
            <tbody>
            {this.props.validationRules.map(item => 
                <tr key={item}>
                   <td>{item.split("=")[0]}</td>
                    <td>=</td>
                    <td>{item.split("=")[1]}</td>
                </tr>
            )}
            </tbody>
        </table>
    </div>

    <button className="btn btn-primary ml-4" type="button" data-toggle="modal" data-target="#mappingModal" onClick={() => this.props.populateMappingModalTitle('Generated Mapping')}>
   						Save generated Mapping
  		</button>
  	<button className="btn btn-primary ml-2" type="button" data-toggle="modal" data-target="#mappingModal" onClick={() => this.props.populateMappingModalTitle('Master Structure')}>
   						Save Master Structure
  	</button>
     <DeleteModal resetIndexNumToDelete={this.resetIndexNumToDelete}  deleteRow={this.deleteRow}/>
    </span>
    }
}

export default Results;