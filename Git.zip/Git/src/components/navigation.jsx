import React, { Component} from 'react';

class Navigation extends Component {

    render(){
        return <nav className="navbar sticky-top navbar-dark bg-dark">
        <span className="navbar-brand text-center mb-0 h1">Welcome to Business Events Configuration Rules</span>
          <div className="pull-right">
            <ul className="navbar-nav">
                <li className="nav-item"><a className="nav-link" href="@{/logout}">Log Out</a></li>
            </ul>
           </div>
        </nav>
    }
}

export default Navigation;