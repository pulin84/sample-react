import React,{ Component } from 'react';
import Navigation from './navigation';
import Search from './search';
import Results from './results';
import SaveModal from './modal';
import httpService from '../services/httpService';
import PNotify from 'pnotify/dist/es/PNotify'
import PNotifyButtons from 'pnotify/dist/es/PNotifyButtons';

const currentDate = new Date();

class Home extends Component {

    state = {
        inputOutputMappings : [],
        validationRules : [],
        availableInputPaths : [],
        businessStartDate : currentDate,
        mappingModalTitle : '',
        searchCriteria : {}
    }

    setSearchResults = (data) =>{
        this.setState({
            inputOutputMappings : data.inputOutputMappings,
            validationRules : data.validationRules,
            availableInputPaths : data.availableInputPaths
        });
    }

    setSelectedDate = (date) => {
        this.setState({businessStartDate : date});
    }

    deleteOuputInputMappingRow = (index) => {
        let inputOutputMappings = this.state.inputOutputMappings;
        inputOutputMappings.splice(index, 1);
        this.setState({inputOutputMappings : inputOutputMappings})
    }
    resetBusinessStartDate = () => {
        this.setState({businessStartDate : currentDate});
    }

    populateMappingModalTitle = (saveType) => {
        this.setState({mappingModalTitle : saveType})
    }

    setSelectedInputToOutput = (event, index) => {
        let inputOutputMappings = this.state.inputOutputMappings;
        let inputOutputMappingItem = inputOutputMappings[index];
        let updatedMapping = inputOutputMappingItem.split("=")[0]+"="+event.target.value;
        inputOutputMappings[index] = updatedMapping;
        this.setState({inputOutputMappings : inputOutputMappings})
    }

    showGeneratedMapping = (requestPayload) => {
        this.setState({searchCriteria : requestPayload});
        httpService.post('generateMapping', requestPayload).then(function(response){
        console.log(response.data);
        PNotify.alert('Mapping Saved Successfully');
        this.setSearchResults(response.data);
       }.bind(this));

    }

    save = () => {
        if (this.state.mappingModalTitle === "Generated Mapping") {
            httpService.post('saveGeneratedMapping', this.state).then(this.callBackForSave);
        } else if(this.state.mappingModalTitle === "Master Structure"){
            httpService.post('saveMasterStructuree', this.state).then(this.callBackForSave);
        } else {
        }
    } 

    callBackForSave = (response) => {
        console.log(response);
    }

   
    render(){
        return <span><Navigation />
                    <Search showGeneratedMapping={this.showGeneratedMapping} />
                    <Results inputOutputMappings={this.state.inputOutputMappings} deleteRow={this.deleteOuputInputMappingRow} validationRules={this.state.validationRules} availableInputPaths={this.state.availableInputPaths} populateMappingModalTitle={this.populateMappingModalTitle} setSelectedInputToOutput={this.setSelectedInputToOutput}/>
                    <SaveModal mappingModalTitle={this.state.mappingModalTitle} resetBusinessStartDate={this.resetBusinessStartDate} setSelectedDate={this.setSelectedDate} businessStartDate={this.state.businessStartDate} save={this.save}/>
               </span>;
    }

    
}
export default Home;