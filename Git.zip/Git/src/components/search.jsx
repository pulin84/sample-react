import React, {Component} from 'react';
import httpService from '../services/httpService';

class Search extends Component {
    
    constructor(props){
        super(props);
    }

    componentDidMount(){
       this.fetchProducerNameList();
    }

    state = {
        producerName : '',
        transactionTypeName : '',
        businessEventName : '',
        producerText : '',
        masterStructureVersionNumber : '',
        producerNameList : [],
        transactionTypeList : [],
        businessEventList : [],
    }

    fetchProducerNameList() {
        httpService.get('fetchProducerList').then(function(response){
            this.setState({producerNameList: response.data})
        }.bind(this));
    }

    fetchTransactionTypeList(producerName) {
        httpService.get('fetchTransactionTypeList', {producerName : producerName}).then(function(response){
            this.setState({businessEventList: []})
            this.setState({transactionTypeList: []})
           this.setState({transactionTypeList: response.data})
        }.bind(this));
    }

    fetchBusinessEventList(transactionTypeName) {
        httpService.get('fetchBusinessEventList', {transactionTypeName : transactionTypeName, producerName : this.state.producerName}).then(function(response){
             this.setState({businessEventList: response.data})
        }.bind(this));
    }

    handleSelectedValue = (event, property) => {
        this.setState({[property] : event.target.value});
        if (property === 'producerName') {
            this.fetchTransactionTypeList(event.target.value);
        }else if (property === 'transactionTypeName') {
            this.fetchBusinessEventList(event.target.value);
        }
    }

    buttonStatus() {
        return !(this.state.producerName && this.state.transactionTypeName && this.state.businessEventName && this.state.producerText && this.state.masterStructureVersionNumber) 
    }
    generateMapping = () => {
        let requestPayload = {
            producerName : this.state.producerName,
            transactionTypeName : this.state.transactionTypeName,
            businessEventName : this.state.businessEventName,
            producerText : this.state.producerText,
            masterStructureVersionNumber : this.state.masterStructureVersionNumber,
        }

        this.props.showGeneratedMapping(requestPayload);
    }
    
  
    render (){
        return <span>
              <div className="form-group row m-3">
                 <div className="col-md-2">
                <label htmlFor="producer">Producer</label>
            </div>
            <div className="col-md-3">
             <select className="form-control" value={this.state.producerName} onChange={(event) => this.handleSelectedValue(event, 'producerName')}>
                     {this.state.producerNameList.map(item => <option key={item} value={item}>{item}</option>)}
			</select>	
            </div>
        </div>

        <div className="form-group row m-3">
            <div className="col-md-2">
                <label htmlFor="transactionType">Transaction Type Name</label>
            </div>
            <div className="col-md-3">
              <select className="form-control" value={this.state.transactionTypeName} onChange={(event) => this.handleSelectedValue(event, 'transactionTypeName')}>
                     {this.state.transactionTypeList.map(item => <option key={item} value={item}>{item}</option>)}
				</select>	
            </div>
        </div>

        <div className="form-group row m-3">
            <div className="col-md-2">
                <label htmlFor="businessEventName">Business Event Name</label>
            </div>
            <div className="col-md-3">
                <select className="form-control" value={this.state.businessEventName} onChange={(event) => this.handleSelectedValue(event, 'businessEventName')}>
                {this.state.businessEventList.map(item => <option key={item} value={item}>{item}</option>)}
			</select>
            </div>
        </div>
      
        <div className="form-group row m-3">
            <div className="col-md-2">
                <label htmlFor="producerText">Producer Text</label>
            </div>
            <div className="col-md-3">
                <input type="text" className="form-control" value={this.state.producerText} onChange={(event) => this.handleSelectedValue(event, 'producerText')} />
            </div>
        </div>
        
        <div className="form-group row m-3">
            <div className="col-md-2">
                <label htmlFor="versionNumber">Master Structure Version Number</label>
            </div>
            <div className="col-md-3">
            <input type="text" className="form-control" value={this.state.masterStructureVersionNumber} onChange={(event) => this.handleSelectedValue(event, 'masterStructureVersionNumber')} />
            </div>
        </div>

        <input type="button" className="btn btn-primary ml-4" value="Generate Mapping" onClick={this.generateMapping} disabled={this.buttonStatus()}/>
        <input type="button" className="btn btn-danger ml-2" value="Delete" />
        </span>
    }
}

export default Search;