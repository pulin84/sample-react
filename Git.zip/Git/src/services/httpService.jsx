import axios from 'axios';

const baseURI = "http://localhost:8082/BEMR/"; 
const httpService = {

    get : function (url, params) {
        return axios({
            method : 'get',
            params: params,
            url : baseURI + url,
            headers :{
                'Access-Control-Allow-Origin' : '*',
                // 'Access-Control-Request-Method' : 'GET',
                // 'Origin' : 'http://localhost:3000'
            },
            auth :{
                username: '',
                password: ''
            }
        });
    },

    post : function (url, data) {
        return axios({
            method : 'post',
            url: baseURI + url,
            auth :{
                username: '',
                password: ''
            },
            data : data
        })
    }
}

export default httpService;