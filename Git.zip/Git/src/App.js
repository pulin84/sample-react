import React, { Component } from 'react';
import './App.css';

const name = "Raju";

class App extends Component {
 

 
  generateMapping(){
    // this.setState({counter : 1});
    console.log('clicked');
  }

  render() {
    return (
     <div className="App" onClick={this.generateMapping}>
       How are you? {name} 
     </div>
    );
  }
}

export default App;
